import{a,b,c,d,e,g as f}from"./chunk-2ELISCRH.js";import"./chunk-CRC5ZNR6.js";f();export{c as Headers,d as Request,e as Response,b as default,a as fetch};
