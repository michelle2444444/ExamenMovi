import{a as r}from"./chunk-MCRJI3T3.js";var n=()=>{if(r!==void 0)return r.Capacitor};export{n as a};
