import{a}from"./chunk-GJZKZXL4.js";import"./chunk-CRC5ZNR6.js";export{a as startFocusVisible};
