import{b as a,c as b}from"./chunk-JWIEPCRG.js";import"./chunk-CRC5ZNR6.js";export{a as GESTURE_CONTROLLER,b as createGesture};
