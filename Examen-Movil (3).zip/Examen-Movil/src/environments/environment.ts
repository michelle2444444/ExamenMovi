// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
  apiKey: "AIzaSyDiLPkmYHHD3-rB68R_S9xzr7Cgzmj5uWc",
  authDomain: "prueba-62d09.firebaseapp.com",
  projectId: "prueba-62d09",
  storageBucket: "prueba-62d09.firebasestorage.app",
  messagingSenderId: "464359626614",
  appId: "1:464359626614:web:85975873d11e4b80184c57",
  measurementId: "G-YLY2EFM4YX"
}
};


